/* ==========================================================================
   DELIVERY BOY — REAL OPENSTREETMAP (OSRM) ROAD GRAPH ENGINE
   ========================================================================== */

(function() {
    'use strict';

    // --- SOUND SYNTHESIZER ENGINE (Web Audio API) ---
    class SoundEngine {
        constructor() {
            this.ctx = null;
            this.muted = false;
        }

        init() {
            if (!this.ctx) {
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                this.ctx = new AudioCtx();
            }
            if (this.ctx.state === 'suspended') {
                this.ctx.resume();
            }
        }

        playTone(freq, type, duration, vol = 0.1) {
            if (this.muted || !this.ctx) return;
            try {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = type;
                osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
                gain.gain.setValueAtTime(vol, this.ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start();
                osc.stop(this.ctx.currentTime + duration);
            } catch (e) {}
        }

        playEngineRev(speedRatio) {
            if (this.muted || !this.ctx || speedRatio <= 0.05) return;
            // Warm, soft 55-90Hz low sine hum (zero harsh noise)
            const pitch = 55 + speedRatio * 35;
            this.playTone(pitch, 'sine', 0.08, 0.012);
        }

        playHorn() {
            this.playTone(440, 'square', 0.3, 0.15);
            setTimeout(() => this.playTone(554, 'square', 0.3, 0.15), 100);
        }

        playCashChime() {
            this.playTone(523, 'sine', 0.12, 0.15);
            setTimeout(() => this.playTone(659, 'sine', 0.12, 0.15), 90);
            setTimeout(() => this.playTone(784, 'sine', 0.2, 0.18), 180);
        }

        playPickup() {
            this.playTone(400, 'sine', 0.1, 0.12);
            setTimeout(() => this.playTone(600, 'sine', 0.12, 0.12), 80);
        }
    }

    const sound = new SoundEngine();

    // Configurable Vehicle Speed & Physics Parameters
    const SPEED_CONFIG = {
        PARKED: 0,
        STREET_CRUISE: 38,   // Normal street ~35-40 km/h
        AVENUE_CRUISE: 52,   // Avenue ~50-60 km/h
        CURVE_SLOWDOWN: 22,  // Curves ~20 km/h
        ACCEL_RATE: 20,      // Acceleration km/h per sec
        DECEL_RATE: 30       // Deceleration km/h per sec
    };

    // Haversine Distance in Meters
    function haversineMeters(lat1, lon1, lat2, lon2) {
        const R = 6371000;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    // Shortest Angle Delta for Continuous 360° Lerp Rotation
    function getShortestAngleDelta(currentAngle, targetAngle) {
        let diff = (targetAngle - currentAngle) % 360;
        if (diff > 180) diff -= 360;
        if (diff < -180) diff += 360;
        return diff;
    }

    // --- GAME DEFINITIONS ---
    const VEHICLES = {
        bike:      { id: 'bike',      name: 'Bicicleta Urbana',      icon: '🚲', speedKmh: 22, maxFuel: 999, price: 0 },
        moped:     { id: 'moped',     name: 'Ciclomotor 50cc',       icon: '🛵', speedKmh: 42, maxFuel: 40, price: 150 },
        moto160:   { id: 'moto160',   name: 'Moto Delivery 160cc',   icon: '🏍️', speedKmh: 68, maxFuel: 70, price: 450 },
        superbike: { id: 'superbike', name: 'Super Moto Turbo Nitro',icon: '🚀', speedKmh: 110, maxFuel: 100, price: 1200 }
    };

    const ITEMS = {
        CALDO_CANA: { id: 'CALDO_CANA', name: 'Caldo de Cana com Limão Gelado', icon: '🥤', desc: 'Lagoa Grande de Patos de Minas!' },
        PIZZA:      { id: 'PIZZA',      name: 'Pizza Quente de Calabresa', icon: '🍕', desc: 'Pizzaria Bella Italia.' },
        BREAD:      { id: 'BREAD',      name: 'Cesta de Pães de Queijo', icon: '🥐', desc: 'Padaria Pão Quente.' },
        PARCEL:     { id: 'PARCEL',     name: 'Encomenda Expressa', icon: '📦', desc: 'Shopping Pátio Central.' },
        PASTEL:     { id: 'PASTEL',     name: 'Pastel de Carne', icon: '🥟', desc: 'Restaura 45% de Energia.' },
        ENERGY:     { id: 'ENERGY',     name: 'Energético Nitro 500ml', icon: '🥤', desc: 'Restaura 50% Hidratação.' },
        MOTOR_PART: { id: 'MOTOR_PART', name: 'Peça de Moto', icon: '⚙️', desc: 'Material de Oficina.' }
    };

    // Real Geographic Landmarks of Patos de Minas - MG
    const REAL_LANDMARKS = [
        {
            id: 'KING_ADEGA',
            name: 'King Adega',
            address: 'Rua Vereador João Pacheco, 2352',
            lat: -18.605451,
            lon: -46.521430,
            icon: '🏪',
            color: '#a855f7',
            hasDelivery: true,
            deliveryData: {
                shopName: 'King Adega',
                shopAddr: 'Rua Vereador João Pacheco, 2352',
                destAddr: 'Rua Joaquim Vida, 147',
                destLat: -18.572807,
                destLon: -46.498372,
                price: 'R$ 12,00',
                distance: '6,1 km',
                time: '13 min',
                type: 'Somente entrega'
            }
        },
        {
            id: 'CALDO_DE_CANA',
            name: 'Caldo de Cana Lagoa Grande',
            address: 'Rua Dr. Ivan Clementino Santana, 167 - Lagoa Grande',
            lat: -18.600712,
            lon: -46.520295,
            icon: '🥤',
            color: '#16a34a'
        },
        {
            id: 'PADARIA',
            name: 'Padaria Pão Quente Patos',
            address: 'Av. Brasil, Centro',
            lat: -18.595500,
            lon: -46.516500,
            icon: '🥐',
            color: '#ca8a04'
        },
        {
            id: 'PIZZARIA',
            name: 'Pizzaria Bella Italia Patos',
            address: 'Av. Fátima Porto',
            lat: -18.603500,
            lon: -46.522500,
            icon: '🍕',
            color: '#ea580c'
        },
        {
            id: 'SHOPPING',
            name: 'Shopping Pátio Central Patos',
            address: 'Rua Major Gote',
            lat: -18.588500,
            lon: -46.513500,
            icon: '🏢',
            color: '#0284c7'
        },
        {
            id: 'GAS_STATION',
            name: 'Posto Shell Lagoa',
            address: 'Av. Juscelino Kubitschek',
            lat: -18.602000,
            lon: -46.517500,
            icon: '⛽',
            color: '#0d9488'
        },
        {
            id: 'GARAGE',
            name: 'Oficina Mecânica Patos',
            address: 'Rua General Osório',
            lat: -18.598000,
            lon: -46.524000,
            icon: '🛠️',
            color: '#4f46e5'
        }
    ];

    const DELIVERY_JOBS = [
        { id: 1, title: 'Caldo de Cana Gelado + Pastel 🥤🥟', origin: 'Caldo de Cana Lagoa Grande', dest: 'Shopping Pátio Central Patos', targetLat: -18.588500, targetLon: -46.513500, item: ITEMS.CALDO_CANA, reward: 45, time: 60 },
        { id: 2, title: 'Pizza Grande de Calabresa 🍕', origin: 'Pizzaria Bella Italia', dest: 'Padaria Pão Quente Patos', targetLat: -18.595500, targetLon: -46.516500, item: ITEMS.PIZZA, reward: 35, time: 50 },
        { id: 3, title: 'Cesta de Pães de Queijo 🥐', origin: 'Padaria Pão Quente', dest: 'Posto Shell Lagoa', targetLat: -18.602000, targetLon: -46.517500, item: ITEMS.BREAD, reward: 28, time: 45 }
    ];

    // --- GAME STATE ---
    const state = {
        running: false,
        paused: false,
        cash: 0.0,
        deliveriesCompleted: 0,
        activeOrder: null,

        player: {
            lat: -18.600712,
            lon: -46.520295,
            heading: 0,
            currentSpeedKmh: 0,
            userTargetSpeedKmh: 20,
            currentVehicle: VEHICLES.bike,
            ownedVehicles: ['bike'],
            hasNOS: false,
            hasThermalBox: false,

            fuel: 40,
            energy: 85,
            thirst: 90,
            health: 100,

            isDriving: false,
            inventory: [null, null, null, null, null, null],
            selectedSlot: 0
        },

        // Navigation Route
        route: {
            points: [],        // Array of [lat, lon]
            currentIndex: 0,
            distanceMeters: 0,
            durationSeconds: 0,
            destinationName: ''
        },

        keys: {}
    };

    // --- LEAFLET MAP ENGINE ---
    let map;
    let motoboyMarker;
    let routePolyline;
    let landmarkMarkers = [];
    let destinationMarker = null;

    // Tile Layers for Label Visibility Rules
    let voyagerNoLabelsLayer;
    let voyagerLabelsLayer;
    let darkNoLabelsLayer;
    let darkLabelsLayer;
    let satelliteLayer;
    let currentMapTheme = 'voyager';

    function initLeafletMap() {
        map = L.map('leaflet-map', {
            center: [-18.600712, -46.520295],
            zoom: 16,
            zoomControl: false,
            attributionControl: false
        });

        voyagerNoLabelsLayer = L.tileLayer('https://basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}.png', { maxZoom: 19 });
        voyagerLabelsLayer = L.tileLayer('https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png', { maxZoom: 19 });
        darkNoLabelsLayer = L.tileLayer('https://basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}.png', { maxZoom: 19 });
        darkLabelsLayer = L.tileLayer('https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', { maxZoom: 19 });
        satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19 });

        voyagerNoLabelsLayer.addTo(map);

        // Top-Down Motoboy Vector Marker Icon (Vista Superior)
        // 0° points North (UP). Helmet in center, headlight pointing front, orange box at rear.
        const motoboyIcon = L.divIcon({
            className: 'motoboy-leaflet-marker',
            html: `
            <div class="motoboy-marker-wrap" id="motoboy-avatar-wrap" style="transform: rotate(0deg);">
                <svg class="motoboy-icon-box" viewBox="0 0 40 40" width="42" height="42">
                    <!-- Rear Delivery Box -->
                    <rect x="11" y="25" width="18" height="13" rx="3" fill="#f97316" stroke="#ffffff" stroke-width="1.5"/>
                    <text x="20" y="34" font-size="7" text-anchor="middle" fill="#ffffff" font-weight="bold">iFood</text>
                    <!-- Rider Body & Helmet (Top-Down View) -->
                    <circle cx="20" cy="18" r="7.5" fill="#0284c7" stroke="#ffffff" stroke-width="1.5"/>
                    <ellipse cx="20" cy="15.5" rx="4.5" ry="2.2" fill="#0f172a"/>
                    <!-- Front Handlebars -->
                    <path d="M 7 9 L 33 9" stroke="#facc15" stroke-width="3" stroke-linecap="round"/>
                    <!-- Headlight Pointer (Facing North/Up at 0°) -->
                    <polygon points="20,1 25,7 15,7" fill="#facc15" stroke="#ffffff" stroke-width="0.5"/>
                </svg>
            </div>`,
            iconSize: [42, 42],
            iconAnchor: [21, 21]
        });

        motoboyMarker = L.marker([-18.600712, -46.520295], { icon: motoboyIcon }).addTo(map);
        motoboyMarker.bindTooltip('<b>🛵 MOTOBOY</b><br>Patos de Minas - MG', { permanent: false, direction: 'top' });

        renderLandmarkMarkers();
        map.on('zoomend', updateStreetLabelVisibility);

        // Unblock free camera drag during motion
        map.on('dragstart', () => {
            isAutoFollowCamera = false;
        });

        map.on('click', (e) => {
            sound.init();
            const clickedLat = e.latlng.lat;
            const clickedLon = e.latlng.lng;
            calculateAndStartRoute(clickedLat, clickedLon, 'Ponto Selecionado no Mapa');
        });
    }

    function renderLandmarkMarkers() {
        landmarkMarkers.forEach(m => map.removeLayer(m));
        landmarkMarkers = [];

        REAL_LANDMARKS.forEach(lm => {
            const icon = L.divIcon({
                className: 'landmark-leaflet-marker',
                html: `<div style="background:${lm.color}; border:2px solid #fff; border-radius:50%; width:38px; height:38px; display:flex; align-items:center; justify-content:center; font-size:18px; box-shadow:0 4px 12px rgba(0,0,0,0.5);">${lm.icon}</div>`,
                iconSize: [38, 38],
                iconAnchor: [19, 19]
            });

            const m = L.marker([lm.lat, lm.lon], { icon, zIndexOffset: 2000 }).addTo(map);
            m.bindTooltip(`<b>${lm.name}</b><br><small>${lm.address}</small>`, { permanent: false, direction: 'top' });
            
            m.on('click', (e) => {
                L.DomEvent.stopPropagation(e);
                sound.init();
                calculateAndStartRoute(lm.lat, lm.lon, lm.name);
            });

            // Interactive Delivery Hover Preview Engine (FASE 1)
            if (lm.hasDelivery) {
                m.on('mouseover', () => showDeliveryPreview(lm));
                m.on('mouseout', () => hideDeliveryPreview());
            }

            landmarkMarkers.push(m);
        });
    }

    async function showDeliveryPreview(lm) {
        if (!lm.deliveryData) return;
        const d = lm.deliveryData;

        // Populate Floating Card UI
        const shopNameEl = document.getElementById('preview-shop-name');
        const shopAddrEl = document.getElementById('preview-shop-addr');
        const destAddrEl = document.getElementById('preview-dest-addr');
        const priceEl = document.getElementById('preview-price-tag');
        const distEl = document.getElementById('preview-dist-val');
        const timeEl = document.getElementById('preview-time-val');
        const typeEl = document.getElementById('preview-type-val');

        if (shopNameEl) shopNameEl.innerText = d.shopName;
        if (shopAddrEl) shopAddrEl.innerText = d.shopAddr;
        if (destAddrEl) destAddrEl.innerText = d.destAddr;
        if (priceEl) priceEl.innerText = d.price;
        if (distEl) distEl.innerText = d.distance;
        if (timeEl) timeEl.innerText = d.time;
        if (typeEl) typeEl.innerText = d.type;

        const card = document.getElementById('delivery-preview-card');
        if (card) card.classList.remove('preview-card-hidden');

        // Highlight Destination Marker 📍
        if (previewDestMarker) map.removeLayer(previewDestMarker);
        const destIcon = L.divIcon({
            className: 'dest-preview-leaflet-marker',
            html: `<div style="background:#ef4444; border:3px solid #fff; border-radius:50%; width:38px; height:38px; display:flex; align-items:center; justify-content:center; font-size:20px; box-shadow:0 0 18px #ef4444;">📍</div>`,
            iconSize: [38, 38],
            iconAnchor: [19, 19]
        });
        previewDestMarker = L.marker([d.destLat, d.destLon], { icon: destIcon }).addTo(map);
        previewDestMarker.bindTooltip(`<b>📍 Destino: ${d.destAddr}</b>`, { permanent: false, direction: 'top' });

        // Accept Delivery Button Listener inside preview card
        const acceptBtn = document.getElementById('btn-accept-preview-delivery');
        if (acceptBtn) {
            acceptBtn.onclick = () => {
                hideDeliveryPreview();
                sound.playCashChime();
                addLog(`📦 ENTREGA ACEITA! Rota OSRM ativada para ${d.destAddr} (${d.price})`, 'warning');
                state.activeOrder = {
                    title: `${d.shopName} ➔ ${d.destAddr}`,
                    reward: 12.00,
                    timeLeft: 780
                };
                updateOrderHUD();
                calculateAndStartRoute(d.destLat, d.destLon, d.destAddr);
            };
        }

        // Request OSRM Preview Polyline (Dashed Line)
        try {
            const url = `https://router.project-osrm.org/route/v1/driving/${lm.lon},${lm.lat};${d.destLon},${d.destLat}?overview=full&geometries=geojson`;
            const res = await fetch(url);
            const data = await res.json();
            if (data.code === 'Ok' && data.routes && data.routes[0]) {
                const previewPoints = data.routes[0].geometry.coordinates.map(c => [c[1], c[0]]);
                if (previewPolyline) map.removeLayer(previewPolyline);
                previewPolyline = L.polyline(previewPoints, {
                    color: '#facc15',
                    weight: 6,
                    opacity: 0.95,
                    lineCap: 'round',
                    lineJoin: 'round',
                    className: 'ifood-route-preview-line'
                }).addTo(map);
            }
        } catch (e) {}
    }

    function hideDeliveryPreview() {
        const card = document.getElementById('delivery-preview-card');
        if (card) card.classList.add('preview-card-hidden');

        if (previewPolyline) {
            map.removeLayer(previewPolyline);
            previewPolyline = null;
        }
        if (previewDestMarker) {
            map.removeLayer(previewDestMarker);
            previewDestMarker = null;
        }
    }

    // --- GOOGLE MAPS STREET LABEL VISIBILITY RULES ---
    function updateStreetLabelVisibility() {
        const zoom = map.getZoom();

        if (currentMapTheme === 'voyager') {
            if (zoom < 15.5) {
                if (map.hasLayer(voyagerLabelsLayer)) map.removeLayer(voyagerLabelsLayer);
                if (!map.hasLayer(voyagerNoLabelsLayer)) map.addLayer(voyagerNoLabelsLayer);
            } else {
                if (map.hasLayer(voyagerNoLabelsLayer)) map.removeLayer(voyagerNoLabelsLayer);
                if (!map.hasLayer(voyagerLabelsLayer)) map.addLayer(voyagerLabelsLayer);
            }
        } else if (currentMapTheme === 'dark') {
            if (zoom < 15.5) {
                if (map.hasLayer(darkLabelsLayer)) map.removeLayer(darkLabelsLayer);
                if (!map.hasLayer(darkNoLabelsLayer)) map.addLayer(darkNoLabelsLayer);
            } else {
                if (map.hasLayer(darkNoLabelsLayer)) map.removeLayer(darkNoLabelsLayer);
                if (!map.hasLayer(darkLabelsLayer)) map.addLayer(darkLabelsLayer);
            }
        }
    }

    function toggleMapTheme() {
        const themes = ['voyager', 'satellite', 'dark'];
        const nextIdx = (themes.indexOf(currentMapTheme) + 1) % themes.length;
        currentMapTheme = themes[nextIdx];

        if (map.hasLayer(voyagerNoLabelsLayer)) map.removeLayer(voyagerNoLabelsLayer);
        if (map.hasLayer(voyagerLabelsLayer)) map.removeLayer(voyagerLabelsLayer);
        if (map.hasLayer(darkNoLabelsLayer)) map.removeLayer(darkNoLabelsLayer);
        if (map.hasLayer(darkLabelsLayer)) map.removeLayer(darkLabelsLayer);
        if (map.hasLayer(satelliteLayer)) map.removeLayer(satelliteLayer);

        if (currentMapTheme === 'satellite') {
            map.addLayer(satelliteLayer);
            addLog('🗺️ Estilo de Mapa: Satélite Real HD');
        } else if (currentMapTheme === 'dark') {
            updateStreetLabelVisibility();
            addLog('🗺️ Estilo de Mapa: Modo Noturno Cyber');
        } else {
            updateStreetLabelVisibility();
            addLog('🗺️ Estilo de Mapa: Urbano HD');
        }
    }

    // --- OSRM REAL ROAD NETWORK GRAPH ROUTING ENGINE ---
    async function calculateAndStartRoute(targetLat, targetLon, destName = 'Destino') {
        const startLat = state.player.lat;
        const startLon = state.player.lon;

        addLog(`🗺️ Calculando rota real por OSRM até ${destName}...`);

        try {
            const url = `https://router.project-osrm.org/route/v1/driving/${startLon},${startLat};${targetLon},${targetLat}?overview=full&geometries=geojson`;
            const res = await fetch(url);
            const data = await res.json();

            if (data.code === 'Ok' && data.routes && data.routes[0]) {
                const routeData = data.routes[0];
                const routePoints = routeData.geometry.coordinates.map(c => [c[1], c[0]]);

                state.route.points = routePoints;
                state.route.currentIndex = 0;
                state.route.distanceMeters = routeData.distance;
                state.route.durationSeconds = routeData.duration;
                state.route.destinationName = destName;

                if (routePolyline) map.removeLayer(routePolyline);
                routePolyline = L.polyline(routePoints, {
                    color: '#06b6d4',
                    weight: 7,
                    opacity: 0.9,
                    lineCap: 'round',
                    lineJoin: 'round',
                    className: 'ifood-route-line'
                }).addTo(map);

                if (destinationMarker) map.removeLayer(destinationMarker);
                const destIcon = L.divIcon({
                    className: 'dest-leaflet-marker',
                    html: `<div style="background:#ef4444; border:2px solid #fff; border-radius:50%; width:32px; height:32px; display:flex; align-items:center; justify-content:center; font-size:16px; box-shadow:0 0 14px #ef4444;">🏁</div>`,
                    iconSize: [32, 32],
                    iconAnchor: [16, 16]
                });
                destinationMarker = L.marker([targetLat, targetLon], { icon: destIcon }).addTo(map);

                state.player.isDriving = true;
                sound.playCashChime();
                addLog(`📍 Rota OSRM calculada: ${(routeData.distance / 1000).toFixed(2)} km (${Math.round(routeData.duration)}s)! Motoboy em movimento pelas ruas.`);
            } else {
                addLog('⚠️ Não foi possível calcular rota pelas ruas. Tente outro ponto.', 'warning');
            }
        } catch (err) {
            addLog('⚠️ Erro de conexão com servidor OSRM. Verifique sua internet.', 'danger');
        }
    }

    // --- GAME LOOP & VEHICLE MOTION ALONG ROAD GEOMETRY ---
    let lastTime = 0;

    function gameLoop(time) {
        const dt = (time - lastTime) / 1000 || 0;
        lastTime = time;

        if (state.running && !state.paused) {
            updateGame(dt);
        }

        requestAnimationFrame(gameLoop);
    }

    function updateGame(dt) {
        let distTraveled = 0;
        if (state.player.isDriving) {
            distTraveled = updateVehicleMovementAlongRoute(dt);
        } else {
            // Decelerate smoothly to 0 when parked
            if (state.player.currentSpeedKmh > 0) {
                state.player.currentSpeedKmh = Math.max(0, state.player.currentSpeedKmh - SPEED_CONFIG.DECEL_RATE * dt);
            }
        }

        updateVitals(dt, distTraveled);
        updateHUD();
    }

    function updateVehicleMovementAlongRoute(dt) {
        const p = state.player;
        const r = state.route;

        if (!p.isDriving || r.points.length === 0 || r.currentIndex >= r.points.length) {
            p.isDriving = false;
            p.currentSpeedKmh = 0;
            return 0;
        }

        const curPoint = [p.lat, p.lon];
        const targetPoint = r.points[r.currentIndex];
        const curLat = p.lat;
        const curLon = p.lon;
        const targetLat = targetPoint[0];
        const targetLon = targetPoint[1];

        const distToTargetMeters = haversineMeters(curLat, curLon, targetLat, targetLon);

        // 1. Determine Target Speed (User Selected Speed + Curve Slowdown)
        let targetSpeedKmh = (p.userTargetSpeedKmh || 20) * (p.hasNOS ? 1.5 : 1.0);
        
        // Detect if next segment involves a sharp corner / turn
        if (r.currentIndex < r.points.length - 1) {
            const nextPoint = r.points[r.currentIndex + 1];
            const angle1 = Math.atan2(targetLon - curLon, targetLat - curLat);
            const angle2 = Math.atan2(nextPoint[1] - targetLon, nextPoint[0] - targetLat);
            const turnAngleDiff = Math.abs(getShortestAngleDelta(angle1 * 180 / Math.PI, angle2 * 180 / Math.PI));

            if (turnAngleDiff > 25) {
                // Reduce speed for curve/turn
                targetSpeedKmh = Math.min(targetSpeedKmh, SPEED_CONFIG.CURVE_SLOWDOWN);
            }
        }

        // Apply progressive acceleration / deceleration
        if (p.currentSpeedKmh < targetSpeedKmh) {
            p.currentSpeedKmh = Math.min(targetSpeedKmh, p.currentSpeedKmh + SPEED_CONFIG.ACCEL_RATE * dt);
        } else if (p.currentSpeedKmh > targetSpeedKmh) {
            p.currentSpeedKmh = Math.max(targetSpeedKmh, p.currentSpeedKmh - SPEED_CONFIG.DECEL_RATE * dt);
        }

        // Distance covered in dt seconds (meters)
        const moveStepMeters = (p.currentSpeedKmh / 3.6) * dt;

        if (distToTargetMeters < moveStepMeters || distToTargetMeters < 0.5) {
            // Reached current segment waypoint
            p.lat = targetLat;
            p.lon = targetLon;
            r.currentIndex++;

            if (r.currentIndex >= r.points.length) {
                // Arrived smoothly at destination!
                p.isDriving = false;
                p.currentSpeedKmh = 0;
                addLog(`🎉 Chegou ao destino: ${r.destinationName}!`, 'warning');
                sound.playCashChime();
                if (state.activeOrder) completeActiveOrder();
                return distToTargetMeters;
            }
            return distToTargetMeters;
        }

        // 2. Interpolate Position Along Segment Geometry
        const ratio = moveStepMeters / distToTargetMeters;
        const dLat = targetLat - curLat;
        const dLon = targetLon - curLon;
        p.lat += dLat * ratio;
        p.lon += dLon * ratio;

        // 3. Absolute Heading Direction & Continuous Lerp Angle Rotation
        const targetHeadingRad = Math.atan2(dLon, dLat);
        const targetHeadingDeg = (targetHeadingRad * 180 / Math.PI);

        // Smooth shortest-path rotation angle lerp
        const deltaAngle = getShortestAngleDelta(p.heading, targetHeadingDeg);
        p.heading += deltaAngle * Math.min(1.0, 14 * dt);

        // Sound engine update (soft sine hum)
        sound.playEngineRev(p.currentSpeedKmh / 100);

        // Fuel consumption while driving
        if (p.currentVehicle.id !== 'bike') {
            p.fuel -= (moveStepMeters / 1000) * 0.15;
            if (p.fuel <= 0) {
                p.fuel = 0;
                p.isDriving = false;
                p.currentSpeedKmh = 0;
                addLog('⛽ O combustível da moto acabou! Vá até um Posto para abastecer.', 'warning');
            }
        }

        // 4. Update Leaflet Motoboy Marker Position & Heading Rotation
        if (motoboyMarker) {
            motoboyMarker.setLatLng([p.lat, p.lon]);
            const wrapEl = document.getElementById('motoboy-avatar-wrap');
            if (wrapEl) {
                wrapEl.style.transform = `rotate(${Math.round(p.heading)}deg)`;
            }
        }

        // iFood Style Auto-Camera Pan Follow Motoboy
        map.panTo([p.lat, p.lon], { animate: true, duration: 0.1 });

        return moveStepMeters;
    }

    // Slow Hydration Decay System (Time + Distance Effort Based)
    function updateVitals(dt, distTraveledMeters = 0) {
        const p = state.player;
        
        // Slow time decay: 0.012% per second (~135 minutes of real play for 100% to 0%)
        p.energy -= 0.15 * dt;
        p.thirst -= 0.012 * dt;

        // Distance effort modifier: 0.002% per 100 meters
        if (distTraveledMeters > 0) {
            p.thirst -= (distTraveledMeters / 100) * 0.002;
        }

        if (p.energy <= 0 || p.thirst <= 0) {
            p.health -= 1.5 * dt;
        }

        p.energy = Math.max(0, Math.min(100, p.energy));
        p.thirst = Math.max(0, Math.min(100, p.thirst));
        p.health = Math.max(0, Math.min(100, p.health));

        if (p.health <= 0) {
            triggerGameOver('Seu motoboy ficou exausto durante a entrega.');
        }
    }

    // --- INVENTORY & ORDERS LOGIC ---
    function addItemToInventory(itemObj) {
        const inv = state.player.inventory;
        for (let i = 0; i < inv.length; i++) {
            if (inv[i] === null) {
                inv[i] = { ...itemObj, count: 1 };
                updateInventoryUI();
                return true;
            } else if (inv[i].id === itemObj.id) {
                inv[i].count++;
                updateInventoryUI();
                return true;
            }
        }
        addLog('⚠️ Mochila do motoboy cheia!', 'warning');
        return false;
    }

    function updateInventoryUI() {
        const slots = document.querySelectorAll('.inv-slot');
        slots.forEach((slotEl, idx) => {
            const item = state.player.inventory[idx];
            const iconEl = slotEl.querySelector('.slot-icon');
            const countEl = slotEl.querySelector('.slot-count');

            if (idx === state.player.selectedSlot) slotEl.classList.add('active');
            else slotEl.classList.remove('active');

            if (item) {
                iconEl.innerText = item.icon;
                countEl.innerText = item.count > 1 ? item.count : '';
            } else {
                iconEl.innerText = '';
                countEl.innerText = '';
            }
        });
    }

    function openOrdersModal() {
        populateOrdersBoard();
        document.getElementById('delivery-modal').classList.remove('hidden');
    }

    function populateOrdersBoard() {
        const container = document.getElementById('orders-list-container');
        if (!container) return;
        container.innerHTML = '';

        DELIVERY_JOBS.forEach(job => {
            const itemCard = document.createElement('div');
            itemCard.className = 'order-item-card';
            itemCard.innerHTML = `
                <div>
                    <h4>${job.title}</h4>
                    <p>Origem: ${job.origin} ➔ Destino: ${job.dest}</p>
                    <span class="order-reward-val">Recompensa: R$ ${job.reward.toFixed(2)}</span>
                </div>
                <button class="btn-accept-order" data-job="${job.id}">Aceitar Entrega</button>
            `;
            container.appendChild(itemCard);
        });

        document.querySelectorAll('.btn-accept-order').forEach(btn => {
            btn.addEventListener('click', () => {
                const jobId = parseInt(btn.dataset.job);
                acceptDeliveryJob(jobId);
                document.getElementById('delivery-modal').classList.add('hidden');
            });
        });
    }

    function acceptDeliveryJob(jobId) {
        const job = DELIVERY_JOBS.find(j => j.id === jobId);
        if (!job) return;

        state.activeOrder = { ...job, timeLeft: job.time };
        addItemToInventory(job.item);
        sound.playCashChime();
        addLog(`📦 Pedido Aceito: ${job.title}! OSRM traçando rota até ${job.dest}...`);
        updateOrderHUD();

        // Calculate OSRM route to order destination
        calculateAndStartRoute(job.targetLat, job.targetLon, job.dest);
    }

    function completeActiveOrder() {
        if (!state.activeOrder) return;
        const tip = Math.floor(Math.random() * 15) + 5;
        const totalPayout = state.activeOrder.reward + tip;
        state.cash += totalPayout;
        state.deliveriesCompleted++;
        sound.playCashChime();
        addLog(`🎉 ENTREGA CONCLUÍDA! Recebeu R$ ${state.activeOrder.reward.toFixed(2)} + Gorjeta de R$ ${tip.toFixed(2)}!`, 'warning');
        state.activeOrder = null;
        updateOrderHUD();
    }

    function updateOrderHUD() {
        const card = document.getElementById('active-order-card');
        if (!card) return;

        if (state.activeOrder) {
            card.classList.remove('idle');
            document.getElementById('order-title-text').innerText = state.activeOrder.title;
            document.getElementById('order-sub-text').innerText = `Entregar em: ${state.activeOrder.dest}`;
            document.getElementById('order-reward').innerText = `R$ ${state.activeOrder.reward.toFixed(2)}`;
        } else {
            card.classList.add('idle');
            document.getElementById('order-title-text').innerText = 'Nenhum Pedido Ativo';
            document.getElementById('order-sub-text').innerText = 'Clique no mapa ou aceite pedidos para traçar rotas OSRM!';
            document.getElementById('order-timer').innerText = '--:--';
            document.getElementById('order-reward').innerText = 'R$ 0,00';
        }
    }

    function updateHUD() {
        const p = state.player;

        const speedKmh = Math.round(p.currentSpeedKmh);
        document.getElementById('speed-display').innerText = speedKmh;

        document.getElementById('bar-fuel').style.width = Math.round((p.fuel / p.currentVehicle.maxFuel) * 100) + '%';
        document.getElementById('val-fuel').innerText = Math.round((p.fuel / p.currentVehicle.maxFuel) * 100) + '%';

        document.getElementById('bar-energy').style.width = Math.round(p.energy) + '%';
        document.getElementById('val-energy').innerText = Math.round(p.energy) + '%';

        document.getElementById('bar-thirst').style.width = Math.round(p.thirst) + '%';
        document.getElementById('val-thirst').innerText = Math.round(p.thirst) + '%';

        document.getElementById('cash-display').innerText = `R$ ${state.cash.toFixed(2)}`;
        document.getElementById('vehicle-type-badge').innerText = p.currentVehicle.name;
    }

    function updateGarageUI() {
        document.querySelectorAll('.btn-buy-veh').forEach(btn => {
            const vehKey = btn.dataset.vehicle;
            const targetVeh = VEHICLES[vehKey];
            if (!targetVeh) return;

            if (state.player.currentVehicle.id === vehKey) {
                btn.innerText = '✓ Equipado';
                btn.style.background = 'linear-gradient(135deg, #10b981, #059669)';
            } else if (state.player.ownedVehicles.includes(vehKey)) {
                btn.innerText = 'Equipar';
                btn.style.background = 'linear-gradient(135deg, #0284c7, #0369a1)';
            } else {
                btn.innerText = `Comprar (R$ ${targetVeh.price.toFixed(2)})`;
                btn.style.background = (state.cash >= targetVeh.price)
                    ? 'linear-gradient(135deg, #facc15, #eab308)'
                    : 'rgba(100, 116, 139, 0.4)';
            }
        });
    }

    function addLog(msg, type = 'info') {
        const logBox = document.getElementById('log-container');
        if (!logBox) return;

        const entry = document.createElement('div');
        entry.className = `log-entry ${type === 'danger' ? 'log-danger' : type === 'warning' ? 'log-warning' : ''}`;
        entry.innerText = msg;
        logBox.appendChild(entry);

        setTimeout(() => {
            entry.style.opacity = '0';
            setTimeout(() => entry.remove(), 300);
        }, 4000);
    }

    function triggerGameOver(reason) {
        state.running = false;
        document.getElementById('death-cause-text').innerText = reason;
        document.getElementById('stat-total-cash').innerText = `R$ ${state.cash.toFixed(2)}`;
        document.getElementById('stat-deliveries-done').innerText = state.deliveriesCompleted;
        document.getElementById('gameover-modal').classList.remove('hidden');
    }

    function resetGame() {
        // Immediately hide start screen overlay & gameover modal
        const startOverlay = document.getElementById('start-overlay');
        if (startOverlay) {
            startOverlay.style.display = 'none';
            startOverlay.classList.add('hidden');
        }

        const gameOverModal = document.getElementById('gameover-modal');
        if (gameOverModal) {
            gameOverModal.style.display = 'none';
            gameOverModal.classList.add('hidden');
        }

        state.cash = 0.0;
        state.deliveriesCompleted = 0;
        state.activeOrder = null;
        state.player.lat = -18.600712;
        state.player.lon = -46.520295;
        state.player.fuel = 40;
        state.player.energy = 85;
        state.player.thirst = 90;
        state.player.health = 100;
        state.player.currentVehicle = VEHICLES.bike;
        state.player.isDriving = false;

        try {
            if (motoboyMarker) motoboyMarker.setLatLng([-18.600712, -46.520295]);
            if (routePolyline && map && map.hasLayer(routePolyline)) map.removeLayer(routePolyline);
            if (destinationMarker && map && map.hasLayer(destinationMarker)) map.removeLayer(destinationMarker);
            if (map) map.setView([-18.600712, -46.520295], 16);
        } catch (e) {}

        updateInventoryUI();
        updateOrderHUD();

        state.running = true;
        state.paused = false;
    }

    // --- EVENT LISTENERS ---
    function setupEventListeners() {
        document.getElementById('btn-map-theme').addEventListener('click', toggleMapTheme);

        const recenterBtn = document.getElementById('btn-recenter-cam');
        if (recenterBtn) {
            recenterBtn.addEventListener('click', recenterCameraOnMotoboy);
        }

        // User Target Speed Selector Buttons [-] 20 km/h [+]
        const minusBtn = document.getElementById('btn-speed-minus');
        const plusBtn = document.getElementById('btn-speed-plus');
        const speedValSpan = document.getElementById('target-speed-val');

        if (minusBtn) {
            minusBtn.addEventListener('click', () => {
                state.player.userTargetSpeedKmh = Math.max(20, (state.player.userTargetSpeedKmh || 20) - 5);
                if (speedValSpan) speedValSpan.innerText = `${state.player.userTargetSpeedKmh} km/h`;
                addLog(`⚡ Velocidade Alvo ajustada: ${state.player.userTargetSpeedKmh} km/h`);
            });
        }

        if (plusBtn) {
            plusBtn.addEventListener('click', () => {
                state.player.userTargetSpeedKmh = Math.min(60, (state.player.userTargetSpeedKmh || 20) + 5);
                if (speedValSpan) speedValSpan.innerText = `${state.player.userTargetSpeedKmh} km/h`;
                addLog(`⚡ Velocidade Alvo ajustada: ${state.player.userTargetSpeedKmh} km/h`);
            });
        }

        document.getElementById('btn-reset-top').addEventListener('click', () => {
            resetGame();
            addLog('🔄 Partida Reiniciada!');
        });

        document.getElementById('btn-open-garage').addEventListener('click', () => {
            updateGarageUI();
            document.getElementById('garage-modal').classList.remove('hidden');
        });
        document.getElementById('btn-close-garage').addEventListener('click', () => {
            document.getElementById('garage-modal').classList.add('hidden');
        });

        document.getElementById('btn-open-orders').addEventListener('click', openOrdersModal);
        document.getElementById('btn-close-orders').addEventListener('click', () => {
            document.getElementById('delivery-modal').classList.add('hidden');
        });

        document.getElementById('btn-close-gas').addEventListener('click', () => {
            document.getElementById('gas-modal').classList.add('hidden');
        });

        document.getElementById('btn-action-horn').addEventListener('click', () => sound.playHorn());

        document.querySelectorAll('.btn-buy-veh').forEach(btn => {
            btn.addEventListener('click', () => {
                const vehKey = btn.dataset.vehicle;
                const targetVeh = VEHICLES[vehKey];
                if (!targetVeh) return;

                if (state.player.ownedVehicles.includes(vehKey)) {
                    state.player.currentVehicle = targetVeh;
                    state.player.fuel = targetVeh.maxFuel;
                    sound.playCashChime();
                    addLog(`🛵 Equipou: ${targetVeh.name}!`);
                } else if (state.cash >= targetVeh.price) {
                    state.cash -= targetVeh.price;
                    state.player.ownedVehicles.push(vehKey);
                    state.player.currentVehicle = targetVeh;
                    state.player.fuel = targetVeh.maxFuel;
                    sound.playCashChime();
                    addLog(`🎉 Comprou e equipou: ${targetVeh.name}!`, 'warning');
                } else {
                    addLog(`Saldo insuficiente para ${targetVeh.name} (R$ ${targetVeh.price.toFixed(2)} necessário).`, 'warning');
                }
                updateHUD();
                updateGarageUI();
            });
        });

        // Start Overlay Button Handler
        const startBtn = document.getElementById('btn-start-game');
        const startOverlay = document.getElementById('start-overlay');

        function triggerGameStart(e) {
            if (e && e.preventDefault) e.preventDefault();
            sound.init();
            resetGame();
        }

        if (startBtn) {
            startBtn.onclick = triggerGameStart;
        }

        if (startOverlay) {
            startOverlay.onclick = function(e) {
                if (e.target === startOverlay) triggerGameStart(e);
            };
        }

        const restartBtn = document.getElementById('btn-restart');
        if (restartBtn) restartBtn.onclick = triggerGameStart;
    }

    // --- INITIALIZATION ---
    window.addEventListener('DOMContentLoaded', () => {
        initLeafletMap();
        setupEventListeners();
        requestAnimationFrame(gameLoop);
    });

})();
