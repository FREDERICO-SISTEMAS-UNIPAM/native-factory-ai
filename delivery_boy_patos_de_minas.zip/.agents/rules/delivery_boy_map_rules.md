# PRINCÍPIOS E REGRAS DE ARQUITETURA — DELIVERY BOY (PATOS DE MINAS - MG)

Este documento define os princípios e restrições arquiteturais que devem ser estritamente mantidos em todas as futuras implementações do jogo **DELIVERY BOY**.

---

## 1. MAPA REAL DA CIDADE (OPENSTREETMAP)
- O jogo utiliza a cidade real de **Patos de Minas - MG** como mapa.
- Fonte de dados geográficos: **OpenStreetMap / CartoDB / Esri World Imagery**.
- O mapa é composto por dados geográficos reais e vetoriais, permitindo manipular individualmente:
  - Ruas, Avenidas e Cruzamentos;
  - Bairros, Praças, Rios e Construções.
- **PROIBIDO**: Tratar o mapa como uma imagem estática de fundo ou captura de tela do Google Maps.
- Referência visual: Acompanhamento de entregas do iFood (mapa limpo, legível, com foco no entregador e na rota).

---

## 2. A MOTO DEVE RESPEITAR A REDE DE RUAS REAL (OSRM / GRAPH)
- O veículo é vinculado à rede viária real e navega estritamente por grafos de rotas (ex: **OSRM - Open Source Routing Machine**).
- **A moto JAMAIS pode**:
  - Atravessar quarteirões, casas, prédios, terrenos ou rios;
  - Cortar praças ou terrenos indevidamente;
  - Calcular linha reta entre origem e destino;
  - Voar ou mover-se livremente sobre pixels do canvas.
- A movimentação ocorre obrigatoriamente vetorizada ao longo dos nós da geometria real das ruas (`[lat, lon]`).

---

## 3. REGRAS DE VISIBILIDADE DE NOMES DE RUAS POR ZOOM
- Proibido exibir todos os nomes de ruas ao mesmo tempo.
- **Zoom Distante (< 15.5)**: Exibir apenas vias principais e referências urbanas limpas (`voyager_nolabels`). Esconder ruas locais.
- **Zoom Intermediário / Próximo (≥ 15.5)**: Exibir ruas locais e nomes de estabelecimentos.
- Rótulos devem se posicionar naturalmente e desaparecer/reaparecer conforme o zoom.

---

## 4. ORIENTAÇÃO DO ENTREGADOR & SPRITE VISTA SUPERIOR
- O sprite da moto representa o veículo visto de cima (vista superior top-down).
- Farol/Ponteiro voltado para o Norte (0°).
- Rotação calculada matematicamente pelo ângulo absoluto do segmento atual da rota:
  ```javascript
  const angleRad = Math.atan2(dLon, dLat);
  const targetAngle = angleRad * (180 / Math.PI);
  ```
- Rotação contínua e suave via menor caminho angular (`getShortestAngleDelta`).
- **PROIBIDO**:
  - Acumular giros ou somar rotações sucessivas;
  - Moto ficar de cabeça para baixo ou andar de lado;
  - Sprite em vista lateral que inverta rodas ao dar retorno de 180°.

---

## 5. CONTROLE DE VELOCIDADE PELO JOGADOR
- A velocidade não pode ser fixa em 20 km/h.
- A velocidade é uma variável física real de deslocamento (`currentSpeedKmh`).
- Interface do usuário possui controle visível: `[ - ]   20 km/h   [ + ]` (incrementos de 5 km/h).
- A velocidade selecionada pelo usuário é a velocidade-alvo real utilizada no cálculo de distância por tempo (`(kmh / 3.6) * dt`).
- Redução automática temporária em curvas acentuadas (> 25°) para ~22 km/h, retornando à velocidade escolhida em seguida.

---

## 6. INDEPENDÊNCIA ENTRE CÂMERA E MOVIMENTO DO VEÍCULO
- **SEPARAÇÃO TOTAL**: Câmera/Mapa e Veículo são sistemas independentes.
- O usuário deve poder dar zoom, afastar, clicar, arrastar (pan) e explorar a cidade sem que isso altere a rota ou pare o veículo.
- **REGRAS DE INTERAÇÃO**:
  - `PRESSIONAR E SEGURAR + ARRASTAR` = Mover câmera (Pan). Não altera rota, não teleporta a moto.
  - `CLIQUE SIMPLES NO MAPA` = Não altera o destino nem zera a rota.
  - `ZOOM IN / ZOOM OUT` = Controles exclusivos da câmera.

---

## 7. ÁUDIO DISCRETO E QUALIDADE DE EXPERIÊNCIA
- Proibido usar oscilador ruidoso tipo "ruído de rasgo" ou som irritante em loop.
- Utilizar áudio sutil, discreto e suave (onda senoidal grave de volume baixo) ou manter o motor silencioso.

---

## 8. DECAIMENTO LENTO DE HIDRATAÇÃO
- A hidratação não pode cair vertiginosamente por segundo ou por frame.
- Perda gradual realista baseada em tempo e distância percorrida (`0.012% por segundo + 0.002% a cada 100m`).
- O jogador deve conseguir realizar de 15 a 20 entregas antes de precisar reidratar.

---

## 9. SEPARAÇÃO DE RESPONSABILIDADES DA ARQUITETURA
- **CÂMERA**: Zoom, Pan, Posição da câmera, Visão da cidade.
- **MAPA**: Tiles OpenStreetMap, Camadas de Zoom, Labels.
- **ROTEAMENTO**: OSRM, Origem, Destino, Geometria da Rota.
- **MOTO**: Posição (Lat/Lon), Heading (Ângulo), Velocidade Física, Interpolação.
- **JOGADOR**: Controle de Velocidade `[- / +]`, Decisões de Entrega.
- **ATRIBUTOS**: Hidratação, Combustível, Energia.

---

## 10. CHECKLIST DE TESTE DE REGRESSÃO OBRIGATÓRIO
Antes de concluir qualquer modificação no mapa/navegação, testar os 23 itens de verificação.

---

## 11. FASE 1 — VISUALIZAÇÃO DE UMA ENTREGA NO MAPA (REGRAS CANÔNICAS)
- **Representação Geográfica**: POI permanente no mapa georreferenciado por coordenadas reais.
  - Exemplo: `King Adega` (`lat: -18.605451, lon: -46.521430`, Rua Vereador João Pacheco, 2352).
  - Destino: Rua Joaquim Vida, 147 (`lat: -18.572807, lon: -46.498372`).
- **Comportamento Interativo (Hover)**:
  - `Mouse SOBRE a empresa`: Exibir Card Flutuante com os dados da entrega (R$ 12,00 | 6,1 km | 13 min), destacar marcador de destino `📍` e desenhar polilinha OSRM tracejada de prévia de rota.
  - `Mouse FORA da empresa`: Ocultar o card e a prévia da rota, mantendo o POI permanente `🏪`.
- **Independência Rígida**: A pré-visualização de rota/entrega **NUNCA** altera a rota atual da moto, não move o veículo e não altera a velocidade.
- **Proibido na Fase 1**: Não implementar detecção por proximidade, match automático ou alteração de rota automática nesta etapa.

---

## 12. POSICIONAMENTO DOS ESTABELECIMENTOS DENTRO DO QUARTEIRÃO
- **Coordenadas Geográficas Reais**: Os estabelecimentos (POIs) permanecem 100% fixados nas suas coordenadas geográficas reais `[lat, lon]`.
- **Diferença de Entidades**:
  - 🛵 **MOTO**: Navega vinculada estritamente ao eixo da rede viária real (OSRM graph).
  - 🏪 **ESTABELECIMENTO**: Permanece na coordenada real do lote/imóvel (pode estar dentro do quarteirão, terreno ou prédio).
- **PROIBIDO**: Mover ou ajustar artificialmente as coordenadas dos estabelecimentos para o meio da rua. Conflitos de sobreposição ou proximidade são resolvidos via z-index/camadas de interação no Leaflet (`zIndexOffset: 1000`), mantendo a precisão geográfica intacta.

---

## 13. CÂMERA LIVRE, RECENTRALIZAÇÃO, HOVER CONTINUO E HIERARQUIA DE POIS
- **Câmera Livre durante a Corrida**: Pan/arraste do mapa permanece 100% ativo durante a movimentação da moto. Ao arrastar, o acompanhamento automático pausa, permitindo explorar a cidade sem afetar a rota ou velocidade do entregador.
- **Botão Recentralizar (`◎`)**: Clique no botão flutuante `◎` reativa a centralização da câmera sobre a moto.
- **Transição de Mouse no Card**: O card da entrega e o POI da loja formam uma área interativa contínua. Mover o cursor do POI para o card não fecha a janela.
- **Botão Aceitar Entrega**: O card flutuante inclui o botão `[ ACEITAR ENTREGA ]`.
- **Prioridade dos POIs**: POIs dos estabelecimentos possuem `zIndexOffset: 2000` e prioridade de interação, nunca sendo bloqueados pelo sprite do entregador na rua.
